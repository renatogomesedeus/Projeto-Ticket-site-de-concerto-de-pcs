@extends('layouts.layout_dashboard', ['title' => 'Estatísticas'])

@section('head')
    <link rel="stylesheet" href="//cdn.jsdelivr.net/chartist.js/latest/chartist.min.css">
@endsection

@section('content')
    <style>
        .card {
            max-height: 300px;
            overflow: hidden;
        }

        .ct-usuarios .ct-bar,
        .ct-visualizacoes .ct-bar {
            stroke-width: 50px;
        }

        .ct-series-a .ct-area,
        .ct-series-a .ct-slice-donut-solid,
        .ct-series-a .ct-slice-pie {
            fill: #f17d98
        }

        .ct-series-a .ct-line,
        .ct-series-a .ct-bar,
        .ct-series-a .ct-point {
            /* stroke: #ad69fb; */
            stroke: #ef476f;

        }

        .ct-series-b .ct-line,
        .ct-series-b .ct-bar,
        .ct-series-b .ct-point {
            stroke: #ffd166;
        }

        .ct-series-c .ct-line,
        .ct-series-c .ct-bar,
        .ct-series-c .ct-point {
            stroke: #07d6a0;
        }

        .ct-series-d .ct-line,
        .ct-series-d .ct-bar,
        .ct-series-d .ct-point {
            stroke: #128ab2;
        }

        .ct-series-e .ct-line,
        .ct-series-e .ct-bar,
        .ct-series-e .ct-point {
            stroke: #095b76;
        }

        .ct-series-f .ct-line,
        .ct-series-f .ct-bar,
        .ct-series-f .ct-point {
            stroke: #d173dd;
        }

        .ct-series-g .ct-line,
        .ct-series-g .ct-bar,
        .ct-series-g .ct-point {
            stroke: #a33ab1;
        }

    </style>

    <div class="row gy-3">
        {{-- card diários --}}
        <div class="col-12">
            <div class="card">
                <div class="card-body">

                    <div class="d-flex justify-content-between">
                        <h4 class="card-title fw-bold h5 ">Tickets diários</h4>
                        <a href="{{ route('tickets') }}" class="btn btn-outline-danger btn-sm">Visualizar todos</a>
                    </div>

                    <div class="ct-diarios ct-perfect-fourth"></div>
                </div>
            </div>
        </div>

        {{-- card mes --}}
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h4 class="card-title fw-bold h5 ">Tickets por mês</h4>
                        <a href="{{ route('tickets') }}" class="btn btn-outline-danger btn-sm">Visualizar todos</a>
                    </div>
                    <div class="ct-mes ct-perfect-fourth"></div>
                </div>
            </div>
        </div>

        {{-- card usuários --}}
        <div class="col-12 col-lg-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between mb-3">
                        <h4 class="card-title fw-bold h5 ">Usuários</h4>
                        <a href="{{ route('usuarios') }}" class="btn btn-outline-dark btn-sm">Visualizar todos</a>
                    </div>
                    <div class="ct-usuarios ct-perfect-fourth"></div>
                </div>
            </div>
        </div>

        {{-- visualizações por 7 dias --}}
        <div class="col-12 col-lg-6">
            <div class="card">
                <img class="card-img-top" src="holder.js/100x180/" alt="">
                <div class="card-body">
                    <h4 class="card-title  fw-bold h5 text-center">Visualizações nos útimos 7 dias</h4>
                    <div class="ct-visualizacoes ct-perfect-fourth"></div>
                </div>
            </div>
        </div>

        <div class="col-12">
            <div class="card">
                <img class="card-img-top" src="holder.js/100x180/" alt="">
                <div class="card-body">
                    <h4 class="card-title  fw-bold h5 ">Visualizações por mês</h4>
                    <div class="ct-visualizacoes-mes ct-perfect-fourth"></div>
                </div>
            </div>
        </div>

    </div>
@endsection

@section('script')

    <script src="//cdn.jsdelivr.net/chartist.js/latest/chartist.min.js"></script>
    <script>

        var data= JSON.parse('<?= $data ?>');
        
        // diários
        new Chartist.Line('.ct-diarios', {
            labels: data.ticketsDiarios.dia.reverse(),
            series: [
                data.ticketsDiarios.tickets.reverse(),
            ]
        }, {
            low: 0,
            showArea: true,
            height: 200
        });

        // mês
        new Chartist.Line('.ct-mes', {
            labels: data.ticketsMes.mes.reverse(),
            series: [
                data.ticketsMes.tickets.reverse(),
            ]
        }, {
            low: 0,
            showArea: true,
            height: 200
        });

        // usuários
        new Chartist.Bar('.ct-usuarios', {
            labels: ['Clientes', 'Funcionários', 'Admins', 'Total'],
            series: data.dadosUsuarios
        }, {
            distributeSeries: true,
            height: 200
        });

        // visualiações
        new Chartist.Bar('.ct-visualizacoes', {
            labels: data.visualizacoesDiarias.data.reverse(),
            series: data.visualizacoesDiarias.views.reverse()
        }, {
            distributeSeries: true,
            height: 200
        });

        // Visualizações por mês
        new Chartist.Line('.ct-visualizacoes-mes', {
            labels: data.visualizacoesMes.mes.reverse(),
            series: [
                data.visualizacoesMes.views.reverse()
            ]
        }, {
            fullWidth: true,
            chartPadding: {
                right: 40
            },
            height: 200
        });

    </script>

@endsection
