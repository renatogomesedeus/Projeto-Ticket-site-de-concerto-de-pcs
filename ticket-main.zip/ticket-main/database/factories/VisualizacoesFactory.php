<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class VisualizacoesFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'views' => $this->faker->numberBetween(100, 1000),
            'created_at' => $this->faker->unique()->dateTimeBetween('-11 months', 'now'),
        ];
    }
}
