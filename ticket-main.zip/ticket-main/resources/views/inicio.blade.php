@extends('layouts.app')

@section('content')

    <div class="container-fluid">
        <div class="row">
            <div
                class=" col-12 col-md-7 col-bg-img  pt-5 text-white px-md-5 d-flex justify-content-center align-items-center">
                <div class="py-4">
                    <div class="px-md-3 py-4">
                        <h1 class="display-5 lh-1 fw-bold">Sistema de tickets para empresas</h1>
                        <p class="fs-5 my-3">
                            Tornando a sua empresa cada vez mais profissional, use o nosso sistema de tickets e para de
                            sofrer esperando por respostas no whatsapp.
                        </p>

                        @guest
                            <div class="mt-4 pb-2">
                                <a href="{{ route('register') }}"
                                    class="text-white text-decoration-none hover-link-criar-conta">
                                    <span class="d-inline-block  me-2">
                                        <span
                                            class="rounded-circle border text-center d-flex justify-content-center align-items-center"
                                            style="width: 35px; height:35px">
                                            <i class="fas fa-arrow-right fa-sm"></i>
                                        </span>
                                    </span>
                                    Criar Conta
                                </a>
                            </div>
                        @endguest
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-5 py-5 e-bg-primary-gradient d-flex justify-content-center align-items-center ">
                <div class="py-4 text-center">
                    <h2 class="fw-bold mb-3 text-white">

                    </h2>
                    <a href="{{ route('tickets.create') }}" class="btn btn-lg btn-light btn-light-custom p-3 px-4">
                        <i class="far fa-edit "></i><br>
                        Enviar Ticket
                    </a>
                    <a href="{{ route('meus_tickets') }}" class="btn btn-lg btn-light btn-light-custom p-3 px-4">
                        <i class="far fa-list-alt"></i><br>
                        Meus Ticket
                    </a>
                    <a href="#" class="btn btn-lg btn-light btn-light-custom p-3 px-4" data-bs-toggle="modal"
                        data-bs-target="#modalInfo">
                        <i class="fas fa-info"></i><br>
                        Sobre
                    </a>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="modalInfo" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Sobre</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                    <h3 style="h3 fw-bold">XXX</h3>
                    <p class="">
                    Desenvolvi esse sistema pois estou abrindo uma micro-empresa de
                    manutenção de computadores e preciso controlar a fila de demandas. Com esse sistema os meus clientes
                    poderão abrir chamados da sua própria residência e eu poderei conversar com eles diretamente pelo meu
                    sistema, então servirá tanto como uma forma de eu controlar os meus clientes, quanto uma forma de eu não
                    receber mensagens no whatsapp fora do horário de trabalho.
                    </p>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>


@endsection
