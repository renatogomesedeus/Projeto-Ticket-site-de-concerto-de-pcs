<?php

namespace App\Http\Controllers\Auth;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Gate;
use App\Http\Requests\CompleteRegistrationRequest;

class CompleteRegistrationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function concluirCadastroSeProfileNull()
    {
        return view('dashboard.usuarios.concluir_cadastro');
    }

    public function updateUserProfile(CompleteRegistrationRequest $request)
    {
        if (Gate::allows('profile_is_null')) {

            $profile= [
                1 => 'administrator',
                2 => 'employee',
                3  => 'client',
            ];

            $user= User::find(auth()->user()->id);
            $user->profile = $profile[$request->profile];
            if($request->profile == 2) {
                $user->status = 'pre_registred';
            }
            $user->save();
            return redirect()->route('home')->with(['cadastro_concluido' => true]);
        }
        return redirect()->route('home');
    }
}
