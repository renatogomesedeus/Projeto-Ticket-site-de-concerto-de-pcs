@extends('layouts.layout_dashboard', ['title' => 'Verificar ticket #' . $ticket->id])

@section('content')

    @if ($errors->any())
        <div class="alert alert-danger pb-0 mb-3">
            <ul class="">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if (session('success_msg'))
        <div class="alert alert-success" role="alert">
            <i class="fas fa-check-circle me-2 fa-lg"></i>
            <strong>{{ session('success_msg') }}</strong>
        </div>
    @endif

    <div class="row">
        <div class="col-12">
            <div class="card">
                <img class="card-img-top" src="holder.js/100x180/" alt="">
                <div class="card-body">

                    <div class="d-flex flex-wrap mb-2 flex-lg-nowrap justify-content-lg-between">
                        <h4 class="card-title w-100">
                            <strong>{{ $ticket->assunto }}</strong> <span class="text-muted">
                                (#{{ $ticket->id }})</span>
                        </h4>
                        <div class="dropdown">
                            <button class="btn btn-light border dropdown-toggle text-truncate" type="button" id="triggerId"
                                data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-exchange-alt me-1"></i>
                                Mudar status
                            </button>
                            <div class="dropdown-menu" aria-labelledby="triggerId">
                                <a class="dropdown-item"
                                    href="{{ route('tickets.mudar_status', ['id' => $ticket->id, 'status' => 'aberto']) }}">
                                    <i class="fas fa-envelope-open text-warning me-1"></i> Abrir
                                </a>
                                <a class="dropdown-item"
                                    href="{{ route('tickets.mudar_status', ['id' => $ticket->id, 'status' => 'fechado']) }}">
                                    <i class="fas fa-check-circle text-success me-1"></i> Fechar
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive mb-3">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Status</th>
                                    <th>Prioridade</th>
                                    <th>Data de envio</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        @if ($ticket->status == 'aberto')
                                            <span class="badge bg-warning">Aberto</span>
                                        @else
                                            <span class="badge bg-success">Fechado</span>
                                        @endif
                                    </td>
                                    <td>
                                        @switch($ticket->prioridade)
                                            @case(4)
                                                Emergência
                                            @break
                                            @case(3)
                                                Alta
                                            @break
                                            @case(2)
                                                Baixa
                                            @break
                                            @default
                                                Normal
                                        @endswitch
                                    </td>
                                    <td>
                                        {{ date('d/m/Y à\\s h:ma', strtotime($ticket->created_at)) }}
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                    </div>

                    @foreach ($ticket->mensagem as $msg)
                        <div class="border-bottom mb-3">
                            <div class="
                                        border-start 
                                        @if ($msg->nome_autor != auth()->user()->name) border-warning @endif
                                border-3 ps-2 py-1
                                ">
                                <h6 class="fw-bold h5 pb-0 mb-0">{{ $msg->nome_autor }}</h6>
                                <small class="text-muted">
                                    <i class="far fa-clock fa-sm"></i>
                                    {{ date('d/m/Y à\\s h:ia', strtotime($msg->created_at)) }}
                                </small>
                            </div>
                            <p class="mt-2 ">
                                {{ $msg->descricao }}
                            </p>
                        </div>
                    @endforeach

                    <div class=" p-3 py-4 rounded" style="background-color: #ddd">
                        <form action="{{ route('responderTicket') }}" method="post">
                            @csrf
                            <input type="hidden" name="ticket_id" value="{{ $ticket->id }}">
                            <input type="hidden" name="nome_autor" value="{{ auth()->user()->name }}">
                            <div class="mb-3">
                                <label for="" class="form-label">Responder:</label>
                                <textarea class="form-control" name="descricao" id="" rows="3" @if ($ticket->status == 'fechado') readonly @endif></textarea>
                            </div>
                            @if ($ticket->status == 'fechado')
                                <button type="button" class="e-btn e-btn-primary" disabled>Enviar</button>
                            @else
                                <button type="submit" class="btn btn-primary">Enviar</button>
                            @endif
                        </form>
                    </div>

                </div>
            </div>
        </div>

    </div>

@endsection
