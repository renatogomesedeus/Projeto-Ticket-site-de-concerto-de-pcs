<header>
    <nav class="navbar navbar-dark  navbar-expand-md  fixed-top py-2">
        <div class="container-fluid px-lg-5 mx-lg-3">
            <a class="navbar-brand fs-3" href="/">Sistema de tickets.</a>



            <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar"
                aria-controls="offcanvasNavbar">
                <i class="fas fa-bars"></i>
            </button>
            <div class="offcanvas offcanvas-end text-center text-md-start" tabindex="-1" id="offcanvasNavbar"
                aria-labelledby="offcanvasNavbarLabel">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
                    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                        aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">

                    <ul class="navbar-nav justify-content-start flex-grow-1 pe-3">

                        @can('cliente')
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="{{ route('tickets.create')}}">
                                Enviar ticket
                            </a>
                        </li>
                        <li class="nav-item mt-0">
                            <a class="nav-link" aria-current="page" href=" {{ route('meus_tickets') }}">
                                Meus ticket
                            </a>
                        </li>
                        @endcan
                        
                        @guest
                            <li class="nav-item">
                                <a class="nav-link" aria-current="page" href="{{ route('tickets.create')}}">
                                    Enviar ticket
                                </a>
                            </li>
                            <li class="nav-item mt-0">
                                <a class="nav-link" aria-current="page" href=" {{ route('meus_tickets') }}">
                                    Meus ticket
                                </a>
                            </li>
                            <li class="nav-item mt-0 ">
                                <a class="nav-link {{ Route::is('login') ? 'active' : '' }} " aria-current="page"
                                    href="{{ route('login') }}">Entrar</a>
                            </li>
                            <li class="nav-item mt-0">
                                <a class="nav-link {{ Route::is('register') ? 'active' : '' }}" aria-current="page"
                                    href="{{ route('register') }}">Criar Conta</a>
                            </li>
                        @endguest
                        @auth
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-bs-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">Meu perfil</a>
                                <div class="dropdown-menu" aria-labelledby="dropdownId">
                                    <span class="dropdown-item-text text-muted">{{ Auth::user()->name }}</span>
                                    <hr class="dropdown-divider">
                                    <a class="dropdown-item" href="{{route('home')}}">Dashboard</a>
                                    <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                        @endauth

                    </ul>


                    <ul class="navbar-nav justify-content-end flex-grow-1 pe-3 d-none">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="{{ route('login') }}">
                                Entrar
                            </a>
                        </li>

                        <li class="nav-item ms-md-3">
                            <a class="e-btn  e-btn-primary e-btn-primary-gradient-3 e-btn-pill "
                                href="{{ route('register') }}" style="border-color: #999">
                                Criar conta
                            </a>
                        </li>



                    </ul>

                </div>
            </div>
        </div>
    </nav>
</header>
