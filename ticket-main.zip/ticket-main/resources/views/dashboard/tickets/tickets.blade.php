@extends('layouts.layout_dashboard', ['title' => 'Todos os tickets'])

@section('content')

@if (session('success_msg'))
        <div class="alert alert-success" role="alert">
            <i class="fas fa-check-circle me-2 fa-lg"></i>
            <strong>{{ session('success_msg') }}</strong>
        </div>
    @endif

    <div class="card">
        <div class="card-body">

            <nav>
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                        <a class="nav-link  {{ isset($_GET['status']) && $_GET['status'] == 'aberto' ? 'bg-white active' : '' }}"
                            aria-current="page" href="{{ route('tickets', ['status' => 'aberto']) }}">
                            Aberto
                            <span class="badge bg-secondary opacity-75">{{ $total['aberto'] }}</span>
                        </a>
                    </li>
                    <li class="nav-item bg-white">
                        <a class="nav-link {{ isset($_GET['status']) && $_GET['status'] == 'fechado' ? 'bg-white active' : '' }}"
                            href="{{ route('tickets', ['status' => 'fechado']) }}">
                            Fechado
                            <span class="badge bg-secondary opacity-75">{{ $total['fechado'] }}</span>
                        </a>
                    </li>
                </ul>
            </nav>

            <div class="table-responsive mt-3">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Ticket ID</th>
                            <th>Autor</th>
                            <th>Assunto</th>
                            <th>Prioridade</th>
                            <th>Status</th>
                            <th>Data de envio</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($tickets as $ticket)
                            <tr>
                                <td>
                                    <a href="{{ route('tickets.show', ['ticket' => $ticket->id]) }}"
                                        class="">#{{ $ticket->id }}</a>
                                </td>
                                <td> 
                                    {{ $ticket->user->name }}
                                    @if ($ticket->status_msg_visualizada->where('status_visualizado_admin', false)->count())
                                        <span class="badge bg-danger rounded-pill">
                                            {{ $ticket->status_msg_visualizada->where('status_visualizado_admin', false)->count() }}
                                        </span>
                                    @endif
                                </td>
                                <td> {{ $ticket->assunto }} </td>
                                <td>
                                    @switch($ticket->prioridade)
                                        @case(4)
                                            Emergência
                                        @break
                                        @case(3)
                                            Alta
                                        @break
                                        @case(2)
                                            Baixa
                                        @break
                                        @default
                                            Normal
                                    @endswitch
                                </td>
                                <td>
                                    @if ($ticket->status == 'aberto')
                                        <span class="badge bg-warning">Aberto</span>
                                    @else
                                        <span class="badge bg-danger">Fechado</span>
                                    @endif
                                </td>
                                <td class="text-truncate">
                                    {{ date('d/m/Y à\\s h:ia', strtotime($ticket->created_at)) }}
                                </td>
                                <td class="text-truncate">
                                    <form action="{{route('tickets.destroy', $ticket->id)}}" method="post"
                                        onSubmit="return confirm('Tem certeza que deseja remover esse ticket?') ">
                                        @method('DELETE')
                                        @csrf
                                        <button type="submit" class="btn btn-danger btn-sm">
                                            <i class="fas fa-trash-alt me-1"></i>
                                            <span class="">Deletar</span>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach

                    </tbody>
                </table>
                @if ($tickets->total() == 0)
                    <div class="alert alert-info" role="alert">
                        Não tem tickets
                    </div>
                @endif
            </div>

            {{ $tickets->links() }}

        </div>
    </div>
@endsection
