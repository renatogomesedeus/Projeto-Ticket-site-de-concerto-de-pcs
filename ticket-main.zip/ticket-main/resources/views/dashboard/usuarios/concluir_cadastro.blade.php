<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Concluir cadastro</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
        integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body class="bg-white">
    <div class="container py-5 my-4 ">
        <div class="col-12 col-md-6 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h1 class="h4 fw-bold card-title">Selecione o tipo de conta para concluir o cadastro</h1>
                </div>
                <div class="card-body">

                    @if ($errors->any())
                        <div class="alert alert-danger pb-0">
                            <ul class="">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form action="{{ route('updateUserProfile') }}" method="post" id="form">
                        @csrf
                        @method('PUT')
                        <div class="mb-3">
                            <label for="profile" class="form-label"></label>
                            <select class="form-select" name="profile" id="profile" required>
                                <option value="" selected>Selecione</option>
                                <option value="3">Cliente</option>
                                <option value="2">Funcionário</option>
                            </select>
                        </div>

                        <div class="text-end">
                            <button type="submit" class="e-btn e-btn-orange">
                                Concluir cadastro
                                <i class="fas fa-arrow-right fa-xs ms-2"></i>
                            </button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</body>

</html>
