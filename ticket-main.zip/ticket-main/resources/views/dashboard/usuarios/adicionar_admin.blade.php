@extends('layouts.layout_dashboard', ['title' => 'Adicionar Administrador'])

@section('content')

    @if ($errors->any())
        <div class="alert alert-danger pb-0 mb-3">
            <ul class="">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if (session('success'))
        <div class="alert alert-success mb-3" role="alert">
            <i class="fas fa-check-circle me-2 fa-lg"></i>
            <strong>Adminstrador adicionado com sucesso</strong>
        </div>
    @endif

    <div class="card">
        <img class="card-img-top" src="holder.js/100x180/" alt="">
        <div class="card-body">
            <h4 class="card-title">Preencha os campos para inserir uma conta de administrador</h4>
            <p class="text-muted">
                <i class="fas fa-exclamation-triangle text-warning"></i>
                Cuidado ao adicionar em uma conta de administrador, o usuário terá acesso privilegiado ao sistema.
            </p>

            <form action="{{ route('post_adicionar_admin') }}" method="post">
                @csrf
                <div class="row g-3">
                    <div class="col-12 col-md-6">
                        <label for="name" class="form-label">Nome</label>
                        <input type="text" class="form-control" name="name" value="{{ old('name') }}" id="name"
                            aria-describedby="helpId" placeholder="" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="email" class="form-label">E-mail</label>
                        <input type="text" class="form-control" name="email" value="{{ old('email') }}" id="email"
                            aria-describedby="helpId" placeholder="" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="password" class="form-label">Senha</label>
                        <input type="password" class="form-control" name="password" id="password" aria-describedby="helpId"
                            placeholder="" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label for="password" class="form-label">Repetir senha</label>
                        <input type="password" class="form-control" name="password_confirmation" id="password"
                            aria-describedby="helpId" placeholder="" required>
                    </div>
                </div>
                <button type="submit" class="e-btn  mt-3 e-btn-primary px-4 rounded-2">
                    Criar conta
                </button>
            </form>

        </div>
    </div>

@endsection
