<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Visualizacoes extends Model
{
    use HasFactory;

    protected $fillable= ['views', 'created_at'];
    protected $appends= [
        'mes_ano', 
        'dia_mes',
    ];

    public function getMesAnoAttribute()
    {
        return $this->created_at->format('m-Y');
    }
    public function getDiaMesAttribute()
    {
        return $this->created_at->format('d-m');
    }
  

}
