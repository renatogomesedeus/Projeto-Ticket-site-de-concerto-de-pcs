
<div class="d-flex flex-wrap  flex-md-column flex-shrink-0 p-3 bg-white border shadow sidebar navbar-expand-md"
    style="">
    <a href="/" class="d-flex align-items-center mb-0 me-md-auto link-dark text-decoration-none">
        <span class="fs-4">Sistema de tickets.
        </span>
    </a>

    <div class=" ms-auto ">
        <button class="navbar-toggler float-end" type="button" data-bs-toggle="offcanvas"
            data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
            <i class="fas fa-bars"></i>
        </button>
    </div>
    <hr>
    <div class="offcanvas offcanvas-end " tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">

        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menu</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body ">
            <div class=" w-100">
                <ul class="nav nav-pills flex-column mb-auto">
                    <li class="nav-item">
                        <a href="{{ route('home') }}"
                            class="nav-link link-dark  {{ Route::is('home') ? 'active' : '' }}" aria-current="page">
                            <i class="fas fa-home fa-lg me-2"></i>
                            Página Inicial
                        </a>
                    </li>
                    @can('admin_or_funcionario')
                        <li>
                            <a href="{{ route('usuarios') }}"
                                class="nav-link link-dark {{ Route::is('usuarios') ? 'active' : '' }}">
                                <i class="fas fa-users fa-lg me-2"></i>
                                Usuários
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('tickets') }}"
                                class="nav-link link-dark {{ Route::is('tickets') || Route::is('ticket') ? 'active' : '' }}">
                                <i class="fas fa-list-alt fa-lg me-2"></i>
                                Todo os tickets
                                @if (\App\Models\StatusMsgVisualizada::where('status_visualizado_admin', false)->count())
                                <span class="badge bg-danger rounded-pill">
                                    {{\App\Models\StatusMsgVisualizada::where('status_visualizado_admin', false)->count()}}
                                </span>
                                @endif
                            </a>
                        </li>
                    @endcan
                    @can('admin')
                        <li>
                            <a href="{{ route('exportar_usuarios') }}"
                                class="nav-link link-dark {{ Route::is('exportar_usuarios') ? 'active' : '' }}">
                                <i class="fas fa-file-export fa-lg me-2"></i>
                                Exportar usuários
                            </a>
                        </li>

                        <li>
                            <a href="{{ route('adicionar_admin') }}"
                                class="nav-link link-dark {{ Route::is('adicionar_admin') ? 'active' : '' }}">
                                <i class="fas fa-user-plus fa-lg me-2"></i>
                                Adicionar admin
                            </a>
                        </li>

                        <li>
                            <a href="{{ route('estatisticas') }}"
                                class="nav-link link-dark {{ Route::is('estatisticas') ? 'active' : '' }}">
                                <i class="fas fa-chart-pie fa-lg me-2"></i>
                                Estatísticas
                            </a>
                        </li>
                    @endcan
                    @can('cliente')
                        <li>
                            <a href="{{ route('tickets.create') }}"
                                class="nav-link link-dark {{ Route::is('tickets.create') ? 'active' : '' }}">
                                <i class="fas fa-edit fa-lg me-2"></i>
                                Enviar ticket
                            </a>
                        </li>
                        <li>
                            <a href="{{ route('meus_tickets') }}"
                                class="nav-link link-dark {{ Route::is('meus_tickets') || Route::is('ticket') ? 'active' : '' }}">
                                <i class="fas fa-list-alt fa-lg me-2"></i>
                                Meus tickets
                                @if (\App\Models\StatusMsgVisualizada::where('status_visualizado_usuario', false)->where('user_id', auth()->user()->id)->count())
                                <span class="badge bg-danger rounded-pill">
                                    {{ \App\Models\StatusMsgVisualizada::where('status_visualizado_usuario', false)->where('user_id', auth()->user()->id)->count() }}
                                </span>
                                @endif
                                </a>
                        </li>
                    @endcan

                    <li>
                        <div class="dropdown d-block d-md-none">
                            <a href="#"
                                class="nav-link  d-flex align-items-center link-dark text-decoration-none dropdown-toggle"
                                id="dropdownUser2" data-bs-toggle="dropdown" aria-expanded="false">

                                <strong>
                                    {{ auth()->user()->name }}
                                    @switch(auth()->user()->profile)
                                        @case('administrator')
                                            (Admin)
                                        @break
                                        @case('employee')
                                            (Funcionário)
                                        @break
                                    @endswitch
                                </strong>
                            </a>
                            <ul class="dropdown-menu text-small shadow" aria-labelledby="dropdownUser2">

                                <li><a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">Sair</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <hr>
    <div class="dropdown d-none d-md-block">
        <a href="#" class="d-flex align-items-center link-dark text-decoration-none dropdown-toggle" id="dropdownUser2"
            data-bs-toggle="dropdown" aria-expanded="false">
            <strong>
                {{ auth()->user()->name }}
                @switch(auth()->user()->profile)
                    @case('administrator')
                        (Admin)
                    @break
                    @case('employee')
                        (Funcionário)
                    @break
                @endswitch
            </strong>
        </a>
        <ul class="dropdown-menu text-small shadow" aria-labelledby="dropdownUser2">

            <li><a class="dropdown-item" href="{{ route('logout') }}"
                    onclick="event.preventDefault();document.getElementById('logout-form').submit();">Sair</a>
            </li>

        </ul>

        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
            @csrf
        </form>
    </div>
</div>

