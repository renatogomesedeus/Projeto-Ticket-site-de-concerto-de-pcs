@extends('layouts.app',  ['title' => 'Criar Conta'])


@section('content')

    <div class="container-fluid">
        <div class="row">
            <div
                class=" col-12 col-md-7 col-bg-img  pt-5 text-white px-md-5 d-flex justify-content-center align-items-center">
                <div class="py-4">
                    <div class="px-md-3">
                        <h1 class="display-5 lh-1 fw-bold">Crie uma conta.</h1>
                        <p class="fs-5 mt-3">
                            Ao criar uma conta você vai conseguir ter acesso ao nosso painel e conseguir
                            enviar seus tickets para ser atendido, crie logo sua conta.
                        </p>
                        
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-5  py-5 e-bg-primary-gradient d-flex flex-wrap justify-content-center align-items-center scroll-y">

                <div class="py-2 text-center row align-items-center  px-3 px-lg-0 ">
                    <h2 class="fw-bold mb-3 text-white">
                       Crie uma conta
                    </h2>

                    <div class="p-4 rounded shadow bg-white col-12 col-md-10 mx-auto text-start">
                        <form method="POST" action="{{ route('register') }}" id="form">
                            @csrf

                            <div class=" mb-3">
                                <label for="name" class=" col-form-label text-md-end">{{ __('Name') }}</label>

                                <div class="">
                                    <input id="name" type="text" class="form-control @error('name') is-invalid @enderror"
                                        name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                                    @error('name')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class=" mb-3">
                                <label for="email" class=" col-form-label text-md-end">{{ __('Email Address') }}</label>

                                <div class="">
                                    <input id="email" type="email" class="form-control @error('email') is-invalid @enderror"
                                        name="email" value="{{ old('email') }}" required autocomplete="email">

                                    @error('email')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class=" mb-3">
                                <label for="password" class=" col-form-label text-md-end">{{ __('Password') }}</label>

                                <div class="">
                                    <input id="password" type="password"
                                        class="form-control @error('password') is-invalid @enderror" name="password"
                                        required autocomplete="new-password">

                                    @error('password')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class=" mb-3">
                                <label for="password-confirm"
                                    class=" col-form-label text-md-end">{{ __('Confirm Password') }}</label>

                                <div class="">
                                    <input id="password-confirm" type="password" class="form-control"
                                        name="password_confirmation" required autocomplete="new-password">
                                </div>
                            </div>

                            <div class=" mb-0">
                                <div class=" ">
                                    <button type="submit" class="e-btn e-btn-primary d-block w-100">
                                        {{ __('Register') }}
                                    </button>
                                </div>
                            </div>
                        </form>

                        {{-- api sociais --}}
                        <div class="d-flex align-items-center my-4" >
                            <hr class="w-100">
                            <div class="px-3 fs-5 text-muted">ou</div>
                            <hr class="w-100">
                        </div>
                        <a href="{{route('auth.social', 'facebook')}}" class="e-btn  e-btn-facebook e-btn-pill d-block py-2">
                            <i class="fab fa-facebook-square me-2"></i> Registre-se com o Facebook
                        </a>
                        <a href="{{route('auth.social', 'google')}}" class="e-btn  e-btn-light e-btn-pill d-block py-2 mt-3 mb-4 " style="box-shadow: 0 0 3px #666">
                            <i class="fab fa-google me-2"></i> Registre-se com o Google
                        </a>
                        <a href="{{route('auth.social', 'github')}}" class="e-btn  e-btn-dark e-btn-pill d-block py-2 mt-3 mb-4 " >
                            <i class="fab fa-github me-2"></i> Registre-se com o Github
                        </a>
                        

                    </div>


                </div>
            </div>
        </div>
    </div>


@endsection
