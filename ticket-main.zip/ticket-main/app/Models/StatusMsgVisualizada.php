<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StatusMsgVisualizada extends Model
{
    use HasFactory;

    protected $fillable = [
        'status_visualizado_admin',
        'status_visualizado_usuario',
        'mensagen_id',
        'ticket_id',
        'user_id',
    ];

    public function ticket()
    {
        return $this->belongsTo(Ticket::class);
    }
}
