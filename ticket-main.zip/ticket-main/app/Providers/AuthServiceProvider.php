<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        // 'App\Models\Model' => 'App\Policies\ModelPolicy',
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();

        Gate::define('profile_is_null', function ($user) {
            return $user->profile == null
                ? true
                : false;
        });

        Gate::define('admin_or_funcionario', function ($user) {
            return $user->profile == 'administrator' || $user->profile == 'employee'
                ? true
                : false;
        });

        Gate::define('admin', function ($user) {
            return $user->profile == 'administrator'
                ? true
                : false;
        });

        Gate::define('funcionario', function ($user) {
            return $user->profile == 'employee'
                ? true
                : false;
        });

        Gate::define('cliente', function ($user) {
            return $user->profile == 'client'
                ? true
                : false;
        });
    }
}
