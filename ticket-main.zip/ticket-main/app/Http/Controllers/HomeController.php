<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Ticket;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth', 'profile_is_null', 'funcionario_pendente', 'status_inactived']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(User $users)
    {

        // dados para admin e funcionário
        $usersTotal = [
            'clientes' => $users->where('profile', 'client')->count(), // totalCliente
            'funcionarios' => $users->where('profile', 'employee')->count(), // totalFuncionario
            'admins' => $users->where('profile', 'administrator')->count(), // totalAdmin
        ];
        $usersPrevia = $users->orderBy('created_at', 'desc')->limit(7)->get();
        $ticketsPrevia = Ticket::orderBy('created_at', 'desc')->limit(7)->get();

        // dados para cliente
        $ticketsPreviaCliente = Ticket::where('user_id', auth()->user()->id)
            ->orderBy('created_at', 'desc')
            ->limit(7)
            ->get();
        $ticketsTotalCliente = [
            'aberto' => Ticket::where('user_id', auth()->user()->id)->where('status', 'aberto')->count(),
            'fechado' => Ticket::where('user_id', auth()->user()->id)->where('status', 'fechado')->count(),
            'total' => Ticket::where('user_id', auth()->user()->id)->count(),
        ];

        return view(
            'dashboard.home',
            compact([
                'usersTotal',
                'usersPrevia',
                'ticketsPrevia',
                'ticketsPreviaCliente',
                'ticketsTotalCliente'
            ])
        );
    }
}
