@extends('layouts.layout_dashboard', ['title' => 'Meus tickets'])

@section('content')

    <div class="card">
        <div class="card-body">

            <nav>
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                        <a class="nav-link  {{ isset($_GET['status']) && $_GET['status'] == 'aberto' ? 'bg-white active' : '' }}"
                            aria-current="page" href="{{ route('meus_tickets', ['status' => 'aberto']) }}">
                            Aberto
                            <span class="badge bg-secondary opacity-75">{{ $total['aberto'] }}</span>
                        </a>
                    </li>
                    <li class="nav-item bg-white">
                        <a class="nav-link {{ isset($_GET['status']) && $_GET['status'] == 'fechado' ? 'bg-white active' : '' }}"
                            href="{{ route('meus_tickets', ['status' => 'fechado']) }}">
                            Fechado
                            <span class="badge bg-secondary opacity-75">{{ $total['fechado'] }}</span>
                        </a>
                    </li>
                </ul>
            </nav>

            <div class="table-responsive mt-3">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Ticket ID</th>
                            <th>Assunto</th>
                            <th>Prioridade</th>
                            <th>Status</th>
                            <th>Data de envio</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($tickets as $ticket)
                            <tr>
                                <td>
                                    <a href="{{ route('tickets.show', ['ticket' => $ticket->id]) }}"
                                        class="">#{{ $ticket->id }}</a>
                                </td>
                                <td> 
                                    {{ $ticket->assunto }}
                                    @if ($ticket->status_msg_visualizada->where('status_visualizado_usuario', false)->where('user_id', auth()->user()->id)->count())
                                        <span class="badge bg-danger rounded-pill">
                                            {{ $ticket->status_msg_visualizada->where('status_visualizado_usuario', false)->where('user_id', auth()->user()->id)->count() }}
                                        </span>
                                    @endif
                                </td>
                                <td>
                                    @switch($ticket->prioridade)
                                        @case(4)
                                            Emergência
                                        @break
                                        @case(3)
                                            Alta
                                        @break
                                        @case(2)
                                            Baixa
                                        @break
                                        @default
                                            Normal
                                    @endswitch
                                </td>
                                <td>
                                    @if ($ticket->status == 'aberto')
                                        <span class="badge bg-warning">Aberto</span>
                                    @else
                                        <span class="badge bg-danger">Fechado</span>
                                    @endif
                                </td>
                                {{-- <td>10/11/2022 às 10:43pm</td> --}}
                                <td class="text-truncate">
                                    {{ date('d/m/Y à\\s h:ia', strtotime($ticket->created_at)) }}
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            {{ $tickets->links() }}

        </div>
    </div>
@endsection
