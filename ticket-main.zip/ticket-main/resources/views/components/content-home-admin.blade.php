<div class="row mb-4">
    <div class="col-12 mb-3 col-md-4">
        <div
            class="px-4 py-4 e-bg-primary-gradient rounded-2 p-3 shadow text-white d-flex justify-content-between align-items-center">
            <div class="pe-3">
                <i class="fas fa-users fa-4x"></i>
            </div>
            <div class="text-end">
                <h2 class="fw-bolder fs-1">{{ $usersTotal['clientes'] }}</h2>
                Clientes cadastrados
            </div>
        </div>
    </div>

    <div class="col-12 mb-3 col-md-4">
        <div
            class="px-4 py-4 e-bg-orange-gradient rounded-2 p-3 shadow text-white d-flex justify-content-between align-items-center">
            <div class="pe-3">
                <i class="fas fa-user-friends fa-4x"></i>
            </div>
            <div class="text-end">
                <h2 class="fw-bolder fs-1">{{ $usersTotal['funcionarios'] }}</h2>
                Funcionários cadastrados
            </div>
        </div>
    </div>

    <div class="col-12 mb-3 col-md-4">
        <div
            class="px-4 py-4 e-bg-danger-gradient rounded-2 p-3 shadow text-white d-flex justify-content-between align-items-center">
            <div class="pe-3">
                <i class="fas fa-users-cog fa-4x"></i>
            </div>
            <div class="text-end">
                <h2 class="fw-bolder fs-1">{{ $usersTotal['admins'] }}</h2>
                Administradores
            </div>
        </div>
    </div>
</div>

<div class="card mb-4">
    <div class="card-body">
        <h3 class="h4 card-title">Últimos usuários cadastrados</h3>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>E-mal</th>
                        <th>Data de cadastro</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($usersPrevia as $user)
                        <tr>
                            <td>{{ $user->name }}</td>
                            <td>{{ $user->email }}</td>
                            <td>{{ $user->created_at->format('d/m/Y') }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>


        <a href="{{ route('usuarios') }}" class="e-btn e-btn-purple">Visualizar todos</a>

    </div>
</div>

<div class="card">
    <div class="card-body">
        <h3 class="h4 card-title">Últimos tickets</h3>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>#ID</th>
                        <th>Nome</th>
                        <th>Assunto</th>
                        <th>Status</th>
                        <th>Prioridade</th>
                        <th>Data de envio</th>
                    </tr>
                </thead>
                <tbody>

                    @foreach ($ticketsPrevia as $ticket)
                        <tr>
                            <td>
                           <a href="{{route('tickets.show', ['ticket' => $ticket->id])}}" class="">#{{$ticket->id}}</a>
                        </td>
                            <td class="text-truncate">{{ $ticket->user->name }}</td>
                            <td>{{ $ticket->assunto }}</td>
                            <td>
                                @if ($ticket->status == 'aberto')
                                        <span class="badge bg-warning">Aberto</span>
                                    @else
                                        <span class="badge bg-danger">Fechado</span>
                                    @endif
                            </td>
                            <td>
                                @switch($ticket->prioridade)
                                @case(4)
                                    Emergência
                                    @break
                                @case(3)
                                    Alta
                                    @break
                                @case(2)
                                    Baixa
                                    @break
                                @default
                                    Normal
                            @endswitch
                            </td>
                            <td class="text-truncate">{{ $ticket->user->created_at->format('d/m/Y à\\s h:ia') }}</td>
                        </tr>
                    @endforeach

                </tbody>
            </table>
        </div>

        @if (empty($ticketsPrevia->toArray()))
            <div class="alert alert-info" role="alert">
                Não tem tickets.
            </div>
        @else
            <a href="{{ route('tickets') }}" class="e-btn e-btn-indigo">Visualizar todos</a>
        @endif

    </div>
</div>
