<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class InicioController extends Controller
{
    public function index()
    {
        // se não tiver usuário na base de dados, vai abrir view para primeiro user ser admin
        if (!User::exists()) {
            return view('auth.cadastro_admin');
        }
        return view('inicio');
    }
}
